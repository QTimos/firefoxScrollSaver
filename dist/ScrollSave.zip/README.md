# firefoxScrollSaver


#### <p align="center">A firefox extention for saving the scroll position on a website and autoreloading it.</p>
